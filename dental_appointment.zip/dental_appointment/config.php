<?php 
define ('DB_HOST', 'localhost');
define ('DB_USER', 'root');
define ('DB_PASS', '');
define ('DB_NAME', 'dental_system');
define ('BASE_PATH', 'http://localhost/dental_appointment');
define('APP_NAME', 'Fojas Dental Clinic')
?>