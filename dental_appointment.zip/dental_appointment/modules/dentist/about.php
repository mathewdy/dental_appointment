<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include '../../includes/styles.php' ?>
    <title>Document</title>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="text-center">
                    <img src="../../assets/img/under-construction.svg" height="300" alt="">
                    <p class="h2">Good things take time.</p>
                    <p class="h5"> This page is under construction.</p>
                    <a href="dashboard.php" class="btn btn-md btn-black ">Go Back</a>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>